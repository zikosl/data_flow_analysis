import React from 'react';
import {
  StyleSheet,
  View,
  Text,
  Image,
  ImageBackground,
  TouchableOpacity,
  Modal,
  SafeAreaView,
  KeyboardAvoidingView,
  Platform,
  TouchableWithoutFeedback,
  Keyboard,
} from 'react-native';
import Input from '../component/input'
import LoginContext from '../context/logincontext';
import { LoginManager, AccessToken,GraphRequest ,GraphRequestManager} from 'react-native-fbsdk';
import Loading from '../component/loading';
import { GoogleSignin } from '@react-native-community/google-signin';
import Language from '../context/language';
import LangBtn from '../component/togglelang';
import TextTraduction from '../component/textlang';
import Phone from '../component/phone';
import auth from '@react-native-firebase/auth'
import { PhoneNumberUtil  } from 'google-libphonenumber';
import API from "../api"
import messaging from '@react-native-firebase/messaging';
import { SharedElement } from 'react-navigation-shared-element';
import palette from '../palette';
import LanguageContext from '../utile/context';

GoogleSignin.configure({
    webClientId: '879076605977-vknkekp2t53guk3fi2sh89f00l1momro.apps.googleusercontent.com',
});
function Login (props)
    {
        const [visible,setVisible] = React.useState(false)
        const [enabled,setEnabled] = React.useState(true)
        const [phone,setPhone] = React.useState(null)
        const phoneUtil = PhoneNumberUtil.getInstance();
        const ctx = React.useContext(LoginContext);

        const updatephone = (g)=>{
            setPhone(g)
            const currentValue = g.replace(/[^\d]/g, '');
            const cvLength = currentValue.length;
            if(cvLength ==9)
            {
                const number = phoneUtil.parseAndKeepRawInput(g,"DZ")
                if(phoneUtil.isValidNumber(number))
                {
                    setEnabled(false)
                }
                else
                {
                    setEnabled(true)
                }
            }
        }
        const login = async (e) =>
        {
            setVisible(true)
            const number = phoneUtil.parseAndKeepRawInput(phone,"DZ")
            const internationalNumber = phoneUtil.formatOutOfCountryCallingNumber(number);
            auth().verifyPhoneNumber(internationalNumber).then((confirmation)=>{
                setVisible(false)
                const currentValue = phone.replace(/[^\d]/g, '');
                props.navigation.navigate('Otp',{
                    confirmation:confirmation,
                    phone:currentValue
                })
            }).catch((e)=>
            {
                setVisible(false)
                alert('try again later')
            })
        }
        const initUser = async token => {
            const PROFILE_REQUEST_PARAMS = {
                fields: {
                string: 'id,email,first_name,last_name,picture.type(large)',
                },
            };
            const profileRequest = new GraphRequest(
                '/me',
                {token, parameters: PROFILE_REQUEST_PARAMS},
                async (error, user) => {
                    const data ={}
                if (error) {
                    
                        alert("Ressayer alterierment")
                        setVisible(false)
                } else {
                        data.id = user.id
                        data.fname = user.first_name
                        data.lname = user.last_name
                        data.mail = user.email
                        data.picture = user.picture.data.url
                        data.provider = 1
                        API.post("client/social",data).then((r)=>{
                            ctx.setInformation(r.data);
                            sendFcmToken(r.data.id).then(e=>ctx.setToken(e));
                            setVisible(false)
                        }).catch((e)=>
                        {
                            if(e.response.status == 401)
                            {
                                alert(e.response.data)
                            }
                            else
                            {
                                alert("Ressayer alterierment")
                            }    
                            setVisible(false)
                        })
                }
                },
            );
            new GraphRequestManager().addRequest(profileRequest).start();
            };
        const onFacebookButtonPress = async () => {
            setVisible(true)
            try
            {
                const result = await LoginManager.logInWithPermissions(['public_profile', 'email']);
                const data = await AccessToken.getCurrentAccessToken();
                initUser(data.accessToken)    
            }
            catch(e)
            {
                alert("Ressayer alterierment")
                setVisible(false)
            }
        }
        const sendFcmToken = async (id) => {
            try {
              await messaging().registerDeviceForRemoteMessages();
              const token = await messaging().getToken();
              await API.post('token', {token:token,id:id});
              return token;
            } catch (err) {
              //Do nothing
              return;
            }
          };
        const onGoogleButtonPress = async () => {
            try
                {
                    setVisible(true)
                    const {user} = await GoogleSignin.signIn();
                    const data ={}
                    data.id = user.id
                    data.fname = user.familyName
                    data.lname = user.givenName
                    data.mail = user.email
                    data.picture = user.photo
                    data.provider = 0
                    API.post("client/social",data).then((r)=>{
                        ctx.setInformation(r.data);
                        sendFcmToken(r.data.id).then(e=>ctx.setToken(e));
                        setVisible(false)
                    }).catch((e)=>
                    {
                        alert("Ressayer alterierment")    
                        setVisible(false)
                    })
                }
            catch(e)
                {
                    alert("Ressayer alterierment")
                    setVisible(false)
                }
        }
        const utile = React.useContext(LanguageContext)
        const font = utile.font();
    return (
        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
            <ImageBackground style={{flex:1,justifyContent:"space-between"}} imageStyle={{opacity:.9,width:null,height:null,resizeMode:"stretch"}} source={require("../images/login.png")}>
                {/* <LangBtn/> */}
                <View style={styles.body}>
                    <SharedElement id="First">
                            <Image style={styles.logo} source={require('../images/logoh1.png')}/>
                    </SharedElement>
                    <SharedElement id='Second'>
                        <Text style={[styles.texts,{fontFamily:font+"-Bold"}]}>{utile.translate('msg2')}</Text>
                    </SharedElement>
                </View>
                <View style={styles.phone}>
                    <Phone setValueChange={updatephone}/>
                    <TouchableOpacity disabled={enabled} onPress={()=>{login()}} style={[styles.btn,enabled && {opacity:.8}]}>
                        <TextTraduction style={styles.text}>Connexion</TextTraduction>
                    </TouchableOpacity>
                </View>
                <View style={{flexDirection:"row",alignSelf:"center",alignItems:'center',paddingTop:12,paddingBottom:16}}>
                        <View style={{borderTopWidth:1,width:40,height:0}}></View>
                        <Text style={{fontSize:14,fontFamily:"MontserratAlternates-Light",marginHorizontal:20}}>OR</Text>
                        <View style={{borderTopWidth:1,width:40,height:0}}></View>
                </View>
                <View style={{flexDirection:"row",backgroundColor:"#ffffff11",paddingVertical:40,alignItems:"center",justifyContent:"space-evenly"}}>
                    <TouchableOpacity onPress={onFacebookButtonPress} style={styles.lobin}>
                        <Image style={styles.img} source={require('../images/facebook.png')}/>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={onGoogleButtonPress} style={styles.lobin}>
                        <Image style={styles.img} source={require('../images/google.png')}/>
                    </TouchableOpacity>
                </View>
                <Loading visible={visible}/>
            </ImageBackground>
        </TouchableWithoutFeedback>
    )}

const styles = StyleSheet.create({
    body:{
        justifyContent:"space-around",
    },
    logo:{
        width:200,
        height:100,
        resizeMode:"contain",
        alignSelf:"center",
        marginTop:20
    },
    texts:
    {
        color:palette.Black,
        textAlign:"center",
        fontSize:17,
        marginHorizontal:60,
        lineHeight:20,
        marginTop:20
    },
    container:{
        flex:1,
    },
    btn:
    {
        backgroundColor:"#303030",
        width:110,
        paddingVertical:15,
        justifyContent:"center",
        alignItems:"center",
        marginHorizontal:10,
        borderRadius:14,
        marginVertical:10,
        alignSelf:"center",
    },
    btnin:
    {
        flex:1,
        justifyContent:"space-between",
        alignItems:"center"
    },
    lg:{
        marginHorizontal:20,
        flex:2
    },
    text:
    {
        color:"#f7db02",
        fontFamily:"MavenPro-Medium",
    },
    logo:{
        width:200,
        height:100,
        resizeMode:"contain",
        alignSelf:"center",
        marginTop:20
    },
    bottom:{
        borderBottomRightRadius:10,
        borderBottomLeftRadius:10,
        marginVertical:10
    },
    top:{
        borderTopRightRadius:10,
        borderTopLeftRadius:10,
        marginVertical:10
    },
    img:{
        width:60,
        height:60,
        resizeMode:"contain"
    },
    btnCTm:{
        backgroundColor:"#303030",
        justifyContent:"center",
        alignItems:"center",
        borderTopRightRadius:24,
        borderTopLeftRadius:24,
        paddingBottom:20,
        paddingTop:10,
        marginBottom:-10
    },
    phone:{
      borderWidth:0,
      elevation:2,
      borderRadius:8,
      backgroundColor:"#ffff",
      justifyContent:"space-between",
      paddingHorizontal:20,
      marginVertical:20,
      marginHorizontal:10,
      paddingVertical:20
    }
});

export default Login;