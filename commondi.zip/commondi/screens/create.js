import React from 'react';
import {
  StyleSheet,
  View,
  Image,
  ImageBackground,
  TouchableOpacity,
  TouchableWithoutFeedback,
  Keyboard,
  Text
} from 'react-native';
import TextTraduction from '../component/textlang';
import Input from '../component/input';
import Loading from '../component/loading';
import API from "../api"
import LoginContext from '../context/logincontext';
import messaging from '@react-native-firebase/messaging';
import LanguageContext from '../utile/context';
import palette from '../palette';

function CreateProfile(props)
    {
        const [visible,setVisible] = React.useState(false);
        const [name,setName] = React.useState("");
        const [prename,setPrename] = React.useState("");
        const Context =React.useContext(LoginContext)
        const {id} = props.route.params;
        const signup = async ()=>{
            setVisible(true)
            const  a = await API.post('client/signup',{
                id:id,
                name:name,
                prename:prename
            })
            setVisible(false)
            Context.setInformation(a.data)
            sendFcmToken(a.data.id).then(e=>Context.setToken(e));
        }
        const sendFcmToken = async (id) => {
            try {
              await messaging().registerDeviceForRemoteMessages();
              const token = await messaging().getToken();
              await API.post('token', {token:token,id:id});
              return token;
            } catch (err) {
              //Do nothing
              return;
            }
          };
            const utile = React.useContext(LanguageContext)
            const font = utile.font();
        return (
            <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
           <ImageBackground style={{flex:1,justifyContent:"space-between"}} imageStyle={{opacity:1,width:null,height:null,resizeMode:"stretch"}} source={require("../images/login.png")}>
            <Image style={styles.logo} source={require('../images/logoh1.png')}/>
            
            <View style={styles.phone}>
                <Input onValueChange={(v)=>setName(v)} placeholder={"Nom"}/>
                <Input onValueChange={(v)=>setPrename(v)} placeholder={"Prenome"}/>
                <TouchableOpacity disabled={name=="" || prename ==""} onPress={()=>{signup()}} style={[styles.btn,visible && {opacity:.8}]}>
                    <Text style={[styles.text,{fontFamily:font+"-SemiBold"}]}>{utile.translate('msg5')}</Text>
                </TouchableOpacity>
            </View>
            <View/>
            <View/>
            <View/>
            <Loading visible ={visible} />
            </ImageBackground>
            </TouchableWithoutFeedback>
        );
};

const styles = StyleSheet.create({
    body:{
        flex:1,justifyContent:"space-between"
    },
    btn:
    {
        backgroundColor:palette.Yellow,
        paddingVertical:15,
        justifyContent:"center",
        alignItems:"center",
        marginHorizontal:25,
        borderRadius:7,
        marginVertical:30,
    },
    text:
    {
        color:palette.Black,
        fontSize:16
    },
    logo:{
        width:200,
        height:100,
        resizeMode:"contain",
        alignSelf:"center",
        marginTop:20
    },
    phone:{
      borderWidth:0,
      elevation:2,
      borderRadius:8,
      backgroundColor:"#ffff",
      marginVertical:20,
      paddingVertical:20,
      marginHorizontal:10,
      paddingHorizontal:10,
      maxHeight:250,
      minHeight:250
    },
    textInputContainer: {
        marginBottom: 20,
    },
    roundedTextInput: {
        borderRadius: 10,
        borderWidth: 4,
    },
    reloader:{
        width:50,height:50,
        alignSelf:"center",
        marginVertical:4
    }
});

export default CreateProfile;