import React from 'react';
import {
  StyleSheet,
  View,
  Text,
  TextInput,
  Image,
  Animated
} from 'react-native';
import palette from '../palette';
import LanguageContext from '../utile/context';

function Input ({onValueChange,value,placeholder,style})
    {
        const [active,setActive] = React.useState(false)
        const animition = React.useRef(new Animated.Value(value=="" ? 1 : 0)).current;
        const first = () => {
            if(value=="")
            Animated.timing(animition, {
              toValue: 1,
              duration: 100,
              useNativeDriver:false
            }).start();
          };
        
          const second = () => {
            Animated.timing(animition, {
              toValue: 0,
              duration: 100,
              useNativeDriver:false
            }).start();
          };
          const top = animition.interpolate({
              inputRange:[0,1],
              outputRange:[-13,13]
          })
          const left = animition.interpolate({
            inputRange:[0,1],
            outputRange:[10,22]
        })
        const utile = React.useContext(LanguageContext)
        const font = utile.font();
        return (
            <Animated.View style={[styles.body,active &&{borderColor:palette.Yellow},style]}>
                <Animated.Text style={[styles.text,{top:top,left:left,fontFamily:font+"-Medium",letterSpacing:1},active && {color:palette.Yellow}]}>{placeholder}</Animated.Text>
                <TextInput placeholder={""} style={[styles.input,{fontFamily:font+"-Medium"}]} 
                caretHidden={true}
                onFocus={()=>{setActive(true);second()}}
                onBlur={()=>{setActive(false);first()}}
                onChangeText={(g)=>{onValueChange(g)}}
                value={value}/>
            </Animated.View>
        );
    }

const styles = StyleSheet.create({
    body:{
        borderWidth:2,
        borderColor:palette.Smoke,
        backgroundColor:"#ffffff88",
        paddingHorizontal:10,
        borderRadius:7,
        marginVertical:10,
        elevation:0
    },
    input:
    {
        fontSize:16,
        fontFamily:"Dosis-Medium",
        borderWidth:0,
    },
    text:{
        position:"absolute",
        fontFamily:"MavenPro-Medium",
        fontSize:16,
        backgroundColor:"#fff",
        paddingHorizontal:5,
        color:'#323232'
    }
});

export default Input;