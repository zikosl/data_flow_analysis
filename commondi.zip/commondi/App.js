import 'react-native-gesture-handler';
import React from 'react';
import {
  StyleSheet,
  View,
  Text,
  Image
} from 'react-native';
import { NavigationContainer,useNavigation } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator,CardStyleInterpolators, TransitionPresets } from '@react-navigation/stack';
import Map from "./screens/map"
import Home from "./screens/Home"
import Search from "./screens/search"
import Profile from './screens/profile';
import All from './screens/all';
import Detaill from './screens/detaill';
import Menu from './screens/menu';
import OtherAll from './screens/otherall';
import Facture from './screens/setting';
import Traitment from './screens/traitment';
import Login from './screens/login'
import PhoneOtp from './screens/phoneotp'
import LoginContext from './context/logincontext';
import DetaillRest from './screens/detaillrest';
import AddPhone from './screens/addphone';
import MyCommands from './screens/mycommands';
import SplashScreen from 'react-native-splash-screen'
import Location from './context/location';
import ProduitFull from './screens/produit';
import FactureUn from './screens/Facture';
import { enableScreens } from 'react-native-screens';
import DetaillCategorie from './screens/detaillcategorie';
import CreateProfile from './screens/create';
import TabBar from './tabbar/tabBar';
import api from './api';
import First from './screens/first';
import { createSharedElementStackNavigator } from 'react-navigation-shared-element';


enableScreens();
const yellow = "#FAD103";
const dark = "#303030";
const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();
const Pann = createStackNavigator();
const PStack = createStackNavigator();
const MapNavige = createStackNavigator();
const RootStack = createStackNavigator();
const LoginRegister = createStackNavigator();
const SharedElementStack = createSharedElementStackNavigator();
function HomeSharedElementStackNavigator() {
  return (
    <SharedElementStack.Navigator
      mode="modal"
      screenOptions={{
        useNativeDriver: true,
        // Enable gestures if you want. I disabled them because of my card style interpolator opacity animation
        gestureEnabled: false,
        // gestureResponseDistance: {
        // 	vertical: 100,
        // },
        // gestureDirection: 'vertical',
        ...TransitionPresets.ModalSlideFromBottomIOS,
        transitionSpec: {
          open: iosTransitionSpec,
          close: iosTransitionSpec,
        },
        // Opacity animation, you can also adjust this by playing with transform properties.
        cardStyleInterpolator: ({ current: { progress } }) => ({
          cardStyle: {
            opacity: progress,
          },
        }),
      }}
      headerMode="none"
    >
      <SharedElementStack.Screen name="First" component={First} />
      <SharedElementStack.Screen
        name="Login"
        component={Login}
        sharedElementsConfig={(route, otherRoute, showing) => {
          if (route.name === "First" && showing) {
            // Open animation fades in image, title and description
            return [
              {
                id: "First",
              },
              {
                id: "Second",
              }
            ];
          } else {
            // Close animation only fades out image
            return [
              {
                id: "First",
              },
              {
                id: "Second",
              }
            ];
          }
        }}
      />
    </SharedElementStack.Navigator>
  );
}
function ProductShared() {
  return (
    <SharedElementStack.Navigator
      mode="modal"
      screenOptions={{
        useNativeDriver: true,
        // Enable gestures if you want. I disabled them because of my card style interpolator opacity animation
        gestureEnabled: false,
        // gestureResponseDistance: {
        // 	vertical: 100,
        // },
        // gestureDirection: 'vertical',
        ...TransitionPresets.ModalSlideFromBottomIOS,
        transitionSpec: {
          open: iosTransitionSpec,
          close: iosTransitionSpec,
        },
        // Opacity animation, you can also adjust this by playing with transform properties.
        cardStyleInterpolator: ({ current: { progress } }) => ({
          cardStyle: {
            opacity: progress,
          },
        }),
      }}
      headerMode="none"
    >
      <SharedElementStack.Screen name="Home" component={Home} />
      <SharedElementStack.Screen
        name="PF"
        component={ProduitFull}
        sharedElementsConfig={(route, otherRoute, showing) => {
          const {image,title} = route.params
          if (route.name === "Home" && showing) {
            // Open animation fades in image, title and description
            return [
              {
                id: image,
              },
              {
                id: title
              }
            ];
          } else {
            // Close animation only fades out image
            return [
              {
                id: image,
              },
              {
                id: title
              }
            ];
          }
        }}
      />
    </SharedElementStack.Navigator>
  );
}
export const iosTransitionSpec = {
  animation: "spring",
  config: {
    stiffness: 1000,
    damping: 500,
    mass: 3,
    overshootClamping: true,
    restDisplacementThreshold: 10,
    restSpeedThreshold: 10,
  },
};
const HomeStack =()=>(
  <Stack.Navigator headerMode="none" screenOptions={{cardStyleInterpolator:CardStyleInterpolators.forNoAnimation}}>
        <Stack.Screen name="HomeStack" component={ProductShared} />
        <Stack.Screen name="Search" component={Search}/>
  </Stack.Navigator>
)
const Pan = (props)=>{
return (
  <Pann.Navigator headerMode="none" screenOptions={{cardStyleInterpolator:CardStyleInterpolators.forNoAnimation}}>
    <Pann.Screen name="Pannier" component={Facture} />
    <Pann.Screen name="AddPhone" component={AddPhone}/>
    <Pann.Screen name="Traitment" component={Traitment}/>
  </Pann.Navigator>
)
}
const MyFacture= (props) =>{
  const ctx = React.useContext(Location);
  const etat = ctx.isAvailable()
  return (
    <>{
      etat ?(
        <Pan {...props}/>
      ):(
        <FactureUn {...props}/>
      )
    }
    </>
  )
}

const RootTab =() => {
  const navigation = useNavigation()
  return (
    <>
      <Tab.Navigator
      tabBar={(props)=>{
        const icons =[require('./icons/home.png'),require('./icons/bag.png'), require('./icons/map.png'),require('./icons/profile.png')]
        return <TabBar {...props} icons={icons}/>
      }}
      >
        <Tab.Screen name="Home" component={HomeStack} />
        <Tab.Screen name="Basket" component={MyFacture} />
        <Tab.Screen name="Map" component={MapView} />
        <Tab.Screen name="Profile" component={ProfileView} />
      </Tab.Navigator>
    </>
  );
};

const LogReg= ()=>
{
 return (
    <LoginRegister.Navigator headerMode="none" initialRouteName='First' screenOptions={{cardStyleInterpolator:CardStyleInterpolators.forNoAnimation}}>
        <LoginRegister.Screen name="Shared" component={HomeSharedElementStackNavigator} />
        <LoginRegister.Screen name="Otp" component={PhoneOtp} />
        <LoginRegister.Screen name="Create" component={CreateProfile} />
    </LoginRegister.Navigator>
)
}
const MapView = () =>{
  return(
    <MapNavige.Navigator headerMode="none" >
      <MapNavige.Screen name='MapView' component={Map}/>
      <MapNavige.Screen name="Categorie" component={DetaillRest} />
      <MapNavige.Screen name="Detaill" component={Detaill} />
      <MapNavige.Screen name="Menu" component={Menu} />
    </MapNavige.Navigator>
  )
}
const ProfileView = ()=>{
  return(
    <PStack.Navigator headerMode="none">
      <PStack.Screen name ='Profile' component={Profile}/>
    </PStack.Navigator>
  )
}
const App= ()=>
{
  const Context = React.useContext(LoginContext)
  const user = Context.isLogin()
  const {id} = Context.login

  React.useEffect(()=>{
      SplashScreen.hide();
  },[])
 return (
  <NavigationContainer>
    <RootStack.Navigator headerMode="none">
      {
        !user ? (
          <RootStack.Screen name="LogReg" component ={LogReg} />
        ):(
          <RootStack.Screen name="Home" component={RootTab} />)
      }
    </RootStack.Navigator>
  </NavigationContainer>
)
}
const styles = StyleSheet.create({
});

export default App;
