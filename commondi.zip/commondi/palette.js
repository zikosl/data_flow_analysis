export default {
    Black:"#1c1e26",
    Yellow:"#ffc700",
    Diablo:"#020403",
    Gray:"#343434",
    Smoke:"#969696"
}