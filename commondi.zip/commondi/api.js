import axios from "axios";

export const  URL = 'http://ltdcommandi.com/'
export default axios.create({
    baseURL:URL
})
